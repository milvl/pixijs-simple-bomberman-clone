import ColorPicker from "./ColorPicker";
import './App.css';

function App() {
  return (
    <div className="App">
      <ColorPicker />
    </div>
  );
}

export default App;

# Structure

- index.js
  - App.js
    - ColorPicker.js
      - ColorWindow.js
      - RGBControllers.js
        - Controller.js
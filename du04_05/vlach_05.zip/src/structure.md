# Structure

- index.js
  - App.js
    - ColorPicker.js
      - ColorWindow.js
      - prevColorWindows.js
      - RGBControllers.js
        - Controller.js
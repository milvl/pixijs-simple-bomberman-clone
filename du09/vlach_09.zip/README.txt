Chtel bych se omluvit za pozdni odevzdani. Vetsinu casu momentalne travim dokoncovanim semestralni prace.

- Lokalizace zarizena pomoci i18next.

- Formatovani (datumu, meny, ...) je reseno pomoci intl a i18next pres renderCell
property v DataGridu.

- I informacni/chybove zpravy jsou lokalizovany pomoci i18next (vcetne vyuziti pluralization
v pripadech jako "1 radka/ 2 radky/ 5 radku").

- Vsechen vykonny kod je v src/App.js. Vsechny metody a casti kodu
by mely byt opatreny dokumentacnimi komentari.

Milan Vlachovsky (A21B0318P)
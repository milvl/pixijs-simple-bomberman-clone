import { TextField, styled } from '@mui/material';

export const CustomTextField = styled(TextField)({
    marginBottom: '16px', // Adds 16px bottom margin
});

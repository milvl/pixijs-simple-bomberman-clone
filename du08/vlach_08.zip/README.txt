Omlouvam se, nestihl jsem do odevzdani dodelat veskerou funkcionalitu, pokusim se ji dodat co nejdrive do opravneho
terminu (na cw 26.5.2024 23:59). Dekuji za pochopeni.

Milan Vlachovsky (A21B0318P)
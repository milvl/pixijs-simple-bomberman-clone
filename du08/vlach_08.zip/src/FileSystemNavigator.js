import React, { useState } from 'react';
import './FileSystemNavigator.css';
import { SimpleTreeView } from '@mui/x-tree-view';
import { styled, alpha } from '@mui/material/styles';
import { TreeItem as MuiTreeItem, treeItemClasses } from '@mui/x-tree-view/TreeItem';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import FolderIcon from '@mui/icons-material/Folder';
import FolderOpenIcon from '@mui/icons-material/FolderOpen';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import Typography from '@mui/material/Typography';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

// Custom styled TreeItem
const TreeItem = styled(MuiTreeItem)(({ theme }) => ({
    [`& .${treeItemClasses.groupTransition}`]: {
        marginLeft: 18,
        paddingLeft: 18,
        borderLeft: `1px dashed ${alpha(theme.palette.text.primary, 0.4)}`,
    }
}));

const collapseIcons = () => {
    return <>
        <FolderOpenIcon />
        <ChevronRightIcon />
    </>
}

const expandIcons = () => {
    return <>
        <FolderIcon />
        <ExpandMoreIcon />
    </>
}

const initialFileSystem = [
    { id: "1", label: "Folder1", type: "folder", children: ["2", "3"], ancestor: null },
    { id: "2", label: "File1.txt", type: "file", content: "This is a text file.", ancestor: "1" },
    { id: "3", label: "Folder2", type: "folder", children: ["4", "5"], ancestor: "1" },
    { id: "4", label: "File2.txt", type: "file", content: "This is an image file.", ancestor: "3" },
    { id: "5", label: "Folder3", type: "folder", children: ["6"], ancestor: "3" },
    { id: "6", label: "File3.css", type: "file", content: "This is an audio file.", ancestor: "5" },
    { id: "7", label: "File4.js", type: "file", content: "This is a js file.", ancestor: null },
    { id: "8", label: "Folder4", type: "folder", children: [], ancestor: null }
];

function FileSystemNavigator() {
    const [fileSystem, setFileSystem] = useState(initialFileSystem);
    const [selectedFileContent, setSelectedFileContent] = useState("No file selected");
    const [selectedItemId, setSelectedItemId] = useState(null);
    const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
    const [openRenameDialog, setOpenRenameDialog] = useState(false);
    const [newName, setNewName] = useState("");

    const handleNodeSelect = (event, itemId) => {
        const file = fileSystem.find(file => file.id === itemId);
        setSelectedFileContent(file.content || "No file selected or is a folder");
        setSelectedItemId(itemId);
    };

    const handleDelete = () => {
        setFileSystem(prev => prev.filter(item => item.id !== selectedItemId));
        setOpenDeleteDialog(false);
        setSelectedItemId(null);
    };

    const handleAdd = () => {
        const newItem = { id: `${new Date().getTime()}`, label: 'New Item', type: 'file', content: '', ancestor: selectedItemId };
        setFileSystem(prev => [...prev, newItem]);
    };

    const handleRename = () => {
        setFileSystem(prev => prev.map(item => item.id === selectedItemId ? { ...item, label: newName } : item));
        setOpenRenameDialog(false);
    };

    const renderTreeItems = (parentId) => {
        return fileSystem.filter(file => file.ancestor === parentId).map(item => {
            return (
                <TreeItem
                    key={item.id}
                    itemId={item.id}
                    label={item.label}
                >
                    {item.type === "folder" && renderTreeItems(item.id)}
                </TreeItem>
            );
        });
    };

    return (
        <div className="FileSystemNavigator">
            <Toolbar>
                <IconButton color="primary" onClick={handleAdd} disabled={!selectedItemId}>
                    <AddIcon />
                </IconButton>
                <IconButton color="secondary" onClick={() => setOpenDeleteDialog(true)} disabled={!selectedItemId}>
                    <DeleteIcon />
                </IconButton>
                <IconButton color="inherit" onClick={() => setOpenRenameDialog(true)} disabled={!selectedItemId}>
                    <EditIcon />
                </IconButton>
            </Toolbar>
            <div className="TreeViewSection">
                <SimpleTreeView
                    aria-label="file system navigator"
                    onNodeSelect={handleNodeSelect}
                    slots={{
                        collapseIcon: collapseIcons,
                        expandIcon: expandIcons,
                    }}
                >
                    {renderTreeItems(null)}
                </SimpleTreeView>
            </div>
            <div className="ContentViewSection">
                <Typography variant="body1" style={{ padding: 20 }}>
                    {selectedFileContent}
                </Typography>
            </div>
            <Dialog open={openDeleteDialog} onClose={() => setOpenDeleteDialog(false)}>
                <DialogTitle>{"Confirm Delete"}</DialogTitle>
                <DialogContent>
                    <DialogContentText>Are you sure you want to delete this item?</DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleDelete} color="primary">Delete</Button>
                    <Button onClick={() => setOpenDeleteDialog(false)} color="primary">Cancel</Button>
                </DialogActions>
            </Dialog>
            <Dialog open={openRenameDialog} onClose={() => setOpenRenameDialog(false)}>
                <DialogTitle>{"Rename Item"}</DialogTitle>
                <DialogContent>
                    <TextField
                        autoFocus
                        margin="dense"
                        id="name"
                        label="New Name"
                        type="text"
                        fullWidth
                        value={newName}
                        onChange={e => setNewName(e.target.value)}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleRename} color="primary">Rename</Button>
                    <Button onClick={() => setOpenRenameDialog(false)} color="primary">Cancel</Button>
                </DialogActions>
            </Dialog>
        </div>
    );
}

export default FileSystemNavigator;

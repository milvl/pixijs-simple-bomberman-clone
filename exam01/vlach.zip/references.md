## References used in the exam

- [MUI X DataGrid Overview](https://mui.com/x/react-data-grid/)
- [MUI X DataGrid API Documentation](https://mui.com/x/api/data-grid/data-grid/)
- [DataGrid Official Demos](https://mui.com/x/react-data-grid/demo/)
- [Select API](https://mui.com/material-ui/api/select/)
Vsechny potrebne informace vcetne uzivatelskeho testovani se nachazi v docs/doc.pdf.

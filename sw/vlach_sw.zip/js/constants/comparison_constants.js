export const COMPARISON_CONSTANTS = {
    EPSILON_SCALE_FACTOR_TO_SCREEN_HEIGHT: 0.0000012987,      // with standard screen height 770, epsilon is 0.001
};
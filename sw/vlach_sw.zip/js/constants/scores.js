export const SCORES = {
    BREAKABLE_WALL: 10,
    ENEMY: 100,
};
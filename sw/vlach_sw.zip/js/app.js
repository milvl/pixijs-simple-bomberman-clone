import * as PIXI from 'pixi.js';
import $ from 'jquery';
import loadAssetsManifest from './loader.js';
import { Game } from './game.js';
import { SoundManager } from './sound_manager.js';

let MODULE_NAME_PREFIX = 'app.js - ';

const RATIO_WIDTH = 21;
const RATIO_HEIGHT = 11 * 1.2;      // 21:11 aspect ratio with hud taking up 20% of the height // TODO better way to calculate this
const GAME_WINDOW_SCALE = 0.8;

const TEXTURES = {};
const AUDIO = {};
const KEY_INPUTS = {};
const SOUND_MANAGER = new SoundManager();

const MANIFEST = {
    bundles: [
        {
            name: "textures",
            assets: [
                { alias: "bunny", src: "./img/bunny.png" },
                { alias: "player", src: "./img/player.png" },
                { alias: "player_walk01", src: "./img/player_walk01.png" },
                { alias: "player_walk02", src: "./img/player_walk02.png" },
                { alias: "player_walk03", src: "./img/player_walk03.png" },
                { alias: "bomb", src: "./img/bomb.png" },
                { alias: "bomb_ignited", src: "./img/bomb_ignited.png" },
                { alias: "explosion", src: "./img/explosion_whole.png" },
                { alias: "wall", src: "./img/wall.png" },
                { alias: "break_wall", src: "./img/break_wall.png" },
                { alias: "door", src: "./img/door.png" },
                { alias: "ghost01", src: "./img/ghost01.png" },
                { alias: "ghost02", src: "./img/ghost02.png" },
                { alias: "ghost03", src: "./img/ghost03.png" },
                { alias: "ghost04", src: "./img/ghost04.png" },
                { alias: "ghost05", src: "./img/ghost05.png" },
                { alias: "ghost06", src: "./img/ghost06.png" },
            ]
        },
        {
            name: "audio",
            assets: [
                { alias: "cursor", src: "./audio/cursor.ogg"},
                { alias: "cursor_submit", src: "./audio/cursor_submit.ogg"},
                { alias: "door_appeared", src: "./audio/door_appeared.ogg"},
                { alias: "explosion_sound", src: "./audio/explosion.ogg"},
                { alias: "new_level", src: "./audio/new_level.ogg"},
                { alias: "player_hit", src: "./audio/player_hit.ogg"},
                { alias: "scored", src: "./audio/scored.mp3"},
            ]
        },
        {
            name: "fonts",
            assets: [
                { alias: "PixelFontTitle", src: "./fonts/Emulogic-zrEw.ttf"},
                { alias: "PixelFontText", src: "./fonts/PressStart2P-vaV7.ttf"}
            ]
        }
    ]
};

/**
 * Config for PIXI application
 */
const PIXI_INIT_CONFIG = { 
    width: getProperDimensions().width,
    height: getProperDimensions().height, 
}

/**
 * Loads a manifest of asset bundles using PIXI Assets.
 * @param {Object} manifest - The manifest object containing bundles of assets.
 * @returns {Promise<Object>} A promise that resolves with the loaded assets.
 * @throws {Error} If there was an error loading the assets.
 */
async function prepareAssets() {
    try {
        const assets = await loadAssetsManifest(MANIFEST);
        return assets;
    } catch (error) {
        console.error(MODULE_NAME_PREFIX, 'Error initializing game assets:', error);
        throw error;  // Re-throw the error to ensure it's propagated
    }
}

/**
 * Returns the proper dimensions for the game window.
 * @returns {Object} The proper dimensions for the game window.
 * @throws {Error} If there was an error getting the proper dimensions.
 */
function getProperDimensions() {
    // find the limiting dimension
    const viewportAspectRatio = window.innerWidth / window.innerHeight;
    const gameAspectRatio = RATIO_WIDTH / RATIO_HEIGHT;

    let width = null;
    let height = null;

    // if the limiting dimension is the height
    if (viewportAspectRatio >= gameAspectRatio) {
        const scaleFactor = window.innerHeight / RATIO_HEIGHT;
        height = window.innerHeight;
        width = RATIO_WIDTH * scaleFactor;

        if (height >= window.screen.height * GAME_WINDOW_SCALE) {
            width *= GAME_WINDOW_SCALE;
            height *= GAME_WINDOW_SCALE;
        }
    }
    // if the limiting dimension is the width
    else {
        const scale_factor = window.innerWidth / RATIO_WIDTH;
        width = window.innerWidth;
        height = RATIO_HEIGHT * scale_factor;

        if (width >= window.screen.width * GAME_WINDOW_SCALE) {
            width *= GAME_WINDOW_SCALE;
            height *= GAME_WINDOW_SCALE;
        }
    }
    
    return { width, height };
}

/**
 * Resizes the canvas to fit the window.
 * @param {PIXI.Application} app - The PIXI application to resize.
 * @param {Object} windowChange - The window change object.
 */
function resizeCanvas(app, windowChange) {
    const { width, height } = getProperDimensions();

    // resize the canvas
    app.renderer.resize(width, height);
    $("#game").css("width", width);
    $("#game").css("height", height);

    windowChange.resized = true;
}

/**
 * Prepares the game assets.
 * @returns {Promise} A promise that resolves when the game assets are prepared.
 * @throws {Error} If there was an error preparing the game assets.
 * @async
 */
async function prepareGameAssets(textures, soundManager) {
    console.log(MODULE_NAME_PREFIX, 'Preparing game assets...');
    const assets = await prepareAssets();
    console.log(MODULE_NAME_PREFIX, 'Assets:', assets);
    loadTextures(assets, textures);
    soundManager.assignSounds(assets);

    console.log(MODULE_NAME_PREFIX, 'Game assets prepared.');
    console.log(MODULE_NAME_PREFIX, 'Textures:', TEXTURES);
    console.log(MODULE_NAME_PREFIX, 'Audio:', AUDIO);
}

/**
 * Loads textures from the assets object into the texture object.
 * @param {Object} assets - The assets object containing the textures.
 * @param {Object} textures - The texture object to load the textures into.
 */
function loadTextures(assets, textures) {
    console.log(MODULE_NAME_PREFIX, 'Loading textures:', assets);
    for (let texture in assets.textures) {
        textures[texture] = PIXI.Texture.from(texture);
    }
    console.log(MODULE_NAME_PREFIX, 'Loaded textures:', textures);
}

/**
 * Keyboard input handler. (borrowed)
 * @param {string} value - The key value.
 * @returns {Object} The key object.
 */
function keyboard(value) {
    const key = {};
    key.value = value;
    key.isDown = false;
    key.isUp = true;
    // functions to be defined by the user
    key.press = undefined;
    key.release = undefined;
    
    // key event handler definitions
    key.keyDownHandler = (event) => {
      if (event.key === key.value) {
        if (key.isUp && key.press) {
          key.press();
        }
        key.isDown = true;
        key.isUp = false;
        event.preventDefault();
      }
    };
    key.keyUpHandler = (event) => {
      if (event.key === key.value) {
        if (key.isDown && key.release) {
          key.release();
        }
        key.isDown = false;
        key.isUp = true;
        event.preventDefault();
      }
    };
  
    // attaching event listeners
    const downListener = key.keyDownHandler.bind(key);
    const upListener = key.keyUpHandler.bind(key);
    window.addEventListener("keydown", downListener, false);
    window.addEventListener("keyup", upListener, false);
    
    // detaching event listeners
    key.unsubscribe = () => {
      window.removeEventListener("keydown", downListener);
      window.removeEventListener("keyup", upListener);
    };
    
    return key;
}

/**
 * Setup function that prepares the data and configuration for the game.
 * @param {PIXI.Application} app - The PIXI application to setup.
 */
async function setup(app) {
    console.log('Setting up game...');

    // prepare game assets
    try {
        await prepareGameAssets(TEXTURES, SOUND_MANAGER);
    } catch (error) {
        console.error(MODULE_NAME_PREFIX, 'Failed to load assets:', error);;
    }

    // setup keyboard input
    KEY_INPUTS.left = keyboard("ArrowLeft");
    KEY_INPUTS.right = keyboard("ArrowRight");
    KEY_INPUTS.up = keyboard("ArrowUp");
    KEY_INPUTS.down = keyboard("ArrowDown");
    KEY_INPUTS.space = keyboard(" ");
    KEY_INPUTS.enter = keyboard("Enter");
    KEY_INPUTS.esc = keyboard("Escape");
    KEY_INPUTS.pause = keyboard("p");
    KEY_INPUTS.pauseUpper = keyboard("P");

    const windowChange = {
        resized: false
    };

    // prompt the user to click to start the game (audio context)
    try {
        await app.init(PIXI_INIT_CONFIG);
    }
    catch (error) {
        console.error(MODULE_NAME_PREFIX, 'Failed to initialize PIXI application:', error);
    }
    
    // mouse click debug
    // app.view.addEventListener('click', (event) => {
    //     // Get the bounding rectangle of the canvas
    //     const rect = app.view.getBoundingClientRect();
    
    //     // Calculate the mouse position relative to the canvas
    //     const x = event.clientX - rect.left;
    //     const y = event.clientY - rect.top;
    
    //     // Log the coordinates
    //     console.log(`Mouse click at canvas coords: (${x}, ${y})`);
    // });
    
    // add the canvas to "game" div
    $("#game").append(app.canvas);
    
    // resize the canvas on window change
    window.addEventListener('resize', () => resizeCanvas(app, windowChange));

    const game = new Game(window, app, TEXTURES, SOUND_MANAGER, KEY_INPUTS, windowChange);
    console.log(MODULE_NAME_PREFIX, 'Game:', game);

    // PIXI's ticker for the game loop
    app.ticker.add((delta) => game.update(delta));
}

////////////////////////////////////////////////// code execution starts here //////////////////////////////////////////////////
// create a new instance of a pixi application
const app = new PIXI.Application();
setup(app);
